<a href="https://Cheataway.com" target="_blank"> <img src="https://cdn.discordapp.com/attachments/853347983639052318/857962898718720030/Rdimos_Github.png" alt="Rdimo's Github"/></a>

```sh-session
pip install bitches
```

<img src="https://komarev.com/ghpvc/?username=rdimo&label=Profile%20Views&color=008042&style=flat&label=Visitors" alt="Visitors"></a>
<img src="https://img.shields.io/badge/dynamic/json?&label=Total%20Stars&color=008042&style=flat&style=for-the-badge&query=%24.stars&url=https://api.github-star-counter.workers.dev/user/Rdimo" alt="Profile Stars"></a>
<img src="https://img.shields.io/badge/dynamic/json?&label=Total%20Forks&color=008042&style=flat&style=for-the-badge&query=%24.forks&url=https://api.github-star-counter.workers.dev/user/Rdimo" alt="Profile Forks"></a>
<a href="https://Cheataway.com" target="_blank"> <img src="https://discordapp.com/api/guilds/991286473888378890/widget.png?style=shield" alt="shield.png"></a>

✔️・**Latest open source project [PyExtractor](https://github.com/Rdimo/PyExtractor)**

📩・**Want to reach? Add Rdimo#6969 on [discord](https://Cheataway.com/invite) or mail [contact.rdimo@gmail.com](mailto:contact.rdimo@gmail.com)**
</a><img align="right" src="https://github-readme-stats.vercel.app/api/top-langs?username=rdimo&count_private=true&hide=procfile,css&theme=dark&border_color=000000&cache_seconds=1800&layout=compact&langs_count=10&custom_title=Most Used Coding Languages" alt="rdimo" /> </p>
🌐・**Website: [https://Cheataway.com](https://Cheataway.com)**

<a href="https://Cheataway.com" target="_blank"> <img src="https://discord.c99.nl/widget/theme-1/991247763587211264.png"/></a>
<a href="https://Cheataway.com" target="_blank"><img src="https://github.com/Rdimo/Rdimo/blob/output/github-contribution-grid-snake.svg" alt="sneke"></a>
